const express = require("express");
const multer = require("multer");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const fs = require("fs");

let session, bcrypt;
try {
  session = require("express-session");
  bcrypt = require("bcrypt");
} catch (err) {
  console.error("ОШИБКА: Необходимые модули не установлены!");
  console.error("Выполните команду: npm install express-session bcrypt");
  console.error("Детали ошибки:", err.message);
  process.exit(1);
}

const app = express();
const PORT = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(
  session({
    secret: "your-secret-key-change-in-production",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: false,
      maxAge: 24 * 60 * 60 * 1000,
    },
  })
);

app.use(express.static(__dirname));
app.use("/styles", express.static(path.join(__dirname, "styles")));

const uploadDir = path.join(__dirname, "uploads");
const avatarsDir = path.join(__dirname, "avatars");

if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

if (!fs.existsSync(avatarsDir)) {
  fs.mkdirSync(avatarsDir, { recursive: true });
}

const db = new sqlite3.Database("files.db");

db.serialize(() => {
  db.run(
    `
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            name TEXT NOT NULL,
            role INTEGER DEFAULT 1,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
     `,
    (err) => {
      if (err) {
        console.error("Ошибка создания таблицы users:", err);
      } else {
        db.run(`ALTER TABLE users ADD COLUMN role INTEGER DEFAULT 1`, (err) => {
          if (err && !err.message.includes("duplicate column")) {
            console.error("Ошибка миграции role:", err);
          }
        });
      }
    }
  );

  db.run(
    `
        CREATE TABLE IF NOT EXISTS files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            name TEXT NOT NULL,
            path TEXT NOT NULL,
            size INTEGER,
            type TEXT,
            upload_date TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
     `,
    (err) => {
      if (err) {
        console.error("Ошибка создания таблицы files:", err);
      }
    }
  );

  db.run(
    `
        CREATE TABLE IF NOT EXISTS avatars (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            filename TEXT NOT NULL,
            path TEXT NOT NULL,
            size INTEGER,
            type TEXT,
            upload_date TEXT,
            is_active INTEGER DEFAULT 1,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
     `,
    (err) => {
      if (err) {
        console.error("Ошибка создания таблицы avatars:", err);
      }
    }
  );
});

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (req, file, cb) => {
    const originalName = file.originalname;
    let filename = originalName;
    let counter = 1;

    while (fs.existsSync(path.join(uploadDir, filename))) {
      const ext = path.extname(originalName);
      const nameWithoutExt = path.basename(originalName, ext);
      filename = `${nameWithoutExt}(${counter})${ext}`;
      counter++;
    }

    cb(null, filename);
  },
});

const avatarStorage = multer.diskStorage({
  destination: avatarsDir,
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const filename = `avatar_${Date.now()}${ext}`;
    cb(null, filename);
  },
});

const upload = multer({ storage: storage });
const avatarUpload = multer({
  storage: avatarStorage,
  fileFilter: (req, file, cb) => {
    const allowedTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Разрешены только изображения (JPEG, PNG, GIF, WebP)"));
    }
  },
  limits: {
    fileSize: 5 * 1024 * 1024,
  },
});

function requireAuth(req, res, next) {
  if (req.session && req.session.userId) {
    return next();
  }
  res.redirect("/login");
}

function requireAuthAPI(req, res, next) {
  if (req.session && req.session.userId) {
    return next();
  }
  res.status(401).json({ error: "Требуется авторизация" });
}

function requireRole(allowedRoles) {
  return (req, res, next) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ error: "Требуется авторизация" });
    }

    const userRole = req.session.userRole || 1;

    if (Array.isArray(allowedRoles)) {
      if (!allowedRoles.includes(userRole)) {
        return res
          .status(403)
          .json({ error: "Доступ запрещен. Недостаточно прав." });
      }
    } else {
      if (userRole !== allowedRoles) {
        return res
          .status(403)
          .json({ error: "Доступ запрещен. Недостаточно прав." });
      }
    }

    next();
  };
}

function requireRolePage(allowedRoles) {
  return (req, res, next) => {
    if (!req.session || !req.session.userId) {
      return res.redirect("/login");
    }

    if (!req.session.userRole) {
      db.get(
        "SELECT role FROM users WHERE id = ?",
        [req.session.userId],
        (err, user) => {
          if (err || !user) {
            return res.redirect("/login");
          }
          req.session.userRole = user.role || 1;
          checkRoleAndContinue();
        }
      );
    } else {
      checkRoleAndContinue();
    }

    function checkRoleAndContinue() {
      const userRole = req.session.userRole || 1;

      if (Array.isArray(allowedRoles)) {
        if (!allowedRoles.includes(userRole)) {
          return res.status(403).send(`
                        <html>
                            <head><title>Доступ запрещен</title></head>
                            <body style="font-family: Arial; text-align: center; padding: 50px;">
                                <h1>Доступ запрещен</h1>
                                <p>У вас недостаточно прав для доступа к этой странице.</p>
                                <p>Требуемая роль: ${
                                  Array.isArray(allowedRoles)
                                    ? allowedRoles.join(" или ")
                                    : allowedRoles
                                }</p>
                                <p>Ваша роль: ${userRole}</p>
                                <a href="/profile">Вернуться в профиль</a>
                            </body>
                        </html>
                    `);
        }
      } else {
        if (userRole !== allowedRoles) {
          return res.status(403).send(`
                        <html>
                            <head><title>Доступ запрещен</title></head>
                            <body style="font-family: Arial; text-align: center; padding: 50px;">
                                <h1>Доступ запрещен</h1>
                                <p>У вас недостаточно прав для доступа к этой странице.</p>
                                <p>Требуемая роль: ${allowedRoles}</p>
                                <p>Ваша роль: ${userRole}</p>
                                <a href="/profile">Вернуться в профиль</a>
                            </body>
                        </html>
                    `);
        }
      }

      next();
    }
  };
}

app.get("/", (req, res) => {
  if (req.session && req.session.userId) {
    return res.redirect("/files");
  }
  res.sendFile(path.join(__dirname, "index.html"));
});

app.get("/login", (req, res) => {
  if (req.session && req.session.userId) {
    return res.redirect("/profile");
  }
  res.sendFile(path.join(__dirname, "login.html"));
});

app.get("/register", (req, res) => {
  if (req.session && req.session.userId) {
    return res.redirect("/profile");
  }
  res.sendFile(path.join(__dirname, "register.html"));
});

app.get("/files", requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "files.html"));
});

app.get("/avatar", requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "avatar.html"));
});

app.get("/profile", requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "profile.html"));
});

app.get("/page1", requireAuth, requireRolePage(1), (req, res) => {
  res.sendFile(path.join(__dirname, "page1.html"));
});

app.get("/page2", requireAuth, requireRolePage(2), (req, res) => {
  res.sendFile(path.join(__dirname, "page2.html"));
});

app.get("/page3", requireAuth, requireRolePage([3, 4]), (req, res) => {
  res.sendFile(path.join(__dirname, "page3.html"));
});

app.post("/api/register", (req, res) => {
  console.log("Получен запрос на регистрацию:", req.body);

  if (!req.body) {
    console.log("Ошибка: тело запроса пустое");
    return res.status(400).json({ error: "Тело запроса пустое" });
  }

  const { email, password, name, role } = req.body;

  if (!email || !password || !name) {
    console.log("Ошибка: не все поля заполнены");
    return res.status(400).json({ error: "Все поля обязательны" });
  }

  const userRole = role ? parseInt(role) : 1;
  if (userRole < 1 || userRole > 4) {
    return res.status(400).json({ error: "Роль должна быть от 1 до 4" });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: "Некорректный формат email" });
  }

  if (password.length < 6) {
    return res
      .status(400)
      .json({ error: "Пароль должен содержать минимум 6 символов" });
  }

  db.get("SELECT id FROM users WHERE email = ?", [email], (err, user) => {
    if (err) {
      console.error("Ошибка базы данных при проверке email:", err);
      return res
        .status(500)
        .json({ error: "Ошибка базы данных: " + err.message });
    }

    if (user) {
      return res
        .status(400)
        .json({ error: "Пользователь с таким email уже существует" });
    }

    bcrypt.hash(password, 10, (err, hashedPassword) => {
      if (err) {
        console.error("Ошибка хеширования пароля:", err);
        return res
          .status(500)
          .json({ error: "Ошибка при обработке пароля: " + err.message });
      }

      db.run(
        "INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)",
        [email, hashedPassword, name, userRole],
        function (err) {
          if (err) {
            console.error("Ошибка базы данных при создании пользователя:", err);
            if (err.message && err.message.includes("UNIQUE constraint")) {
              return res
                .status(400)
                .json({ error: "Пользователь с таким email уже существует" });
            }
            return res.status(500).json({
              error: "Ошибка при создании пользователя: " + err.message,
            });
          }

          req.session.userId = this.lastID;
          req.session.userEmail = email;
          req.session.userName = name;
          req.session.userRole = userRole;

          console.log(
            "Пользователь успешно зарегистрирован:",
            email,
            "Роль:",
            userRole
          );
          res.json({ success: true, message: "Регистрация успешна" });
        }
      );
    });
  });
});

app.post("/api/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email и пароль обязательны" });
  }

  db.get("SELECT * FROM users WHERE email = ?", [email], async (err, user) => {
    if (err) {
      console.error("Ошибка базы данных:", err);
      return res.status(500).json({ error: "Ошибка базы данных" });
    }

    if (!user) {
      return res.status(401).json({ error: "Неверный email или пароль" });
    }

    try {
      const match = await bcrypt.compare(password, user.password);

      if (!match) {
        return res.status(401).json({ error: "Неверный email или пароль" });
      }

      req.session.userId = user.id;
      req.session.userEmail = user.email;
      req.session.userName = user.name;
      req.session.userRole = user.role || 1;

      res.json({ success: true, message: "Вход выполнен успешно" });
    } catch (error) {
      console.error("Ошибка:", error);
      res.status(500).json({ error: "Ошибка сервера" });
    }
  });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: "Ошибка при выходе" });
    }
    res.json({ success: true, message: "Выход выполнен успешно" });
  });
});

app.get("/api/user", requireAuthAPI, (req, res) => {
  db.get(
    "SELECT id, email, name, role, created_at FROM users WHERE id = ?",
    [req.session.userId],
    (err, user) => {
      if (err) {
        console.error("Ошибка базы данных:", err);
        return res.status(500).json({ error: "Ошибка базы данных" });
      }

      if (!user) {
        return res.status(404).json({ error: "Пользователь не найден" });
      }

      db.get(
        "SELECT * FROM avatars WHERE user_id = ? AND is_active = 1 ORDER BY upload_date DESC LIMIT 1",
        [user.id],
        (err, avatar) => {
          if (err) {
            console.error("Ошибка получения аватара:", err);
          }

          const userData = {
            ...user,
            avatar: avatar
              ? {
                  id: avatar.id,
                  url: `/avatar/file/${avatar.id}`,
                  filename: avatar.filename,
                }
              : null,
          };

          res.json(userData);
        }
      );
    }
  );
});

app.put("/api/user", requireAuthAPI, (req, res) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.status(400).json({ error: "Имя и email обязательны" });
  }

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: "Некорректный формат email" });
  }

  db.get(
    "SELECT id FROM users WHERE email = ? AND id != ?",
    [email, req.session.userId],
    (err, user) => {
      if (err) {
        console.error("Ошибка базы данных:", err);
        return res.status(500).json({ error: "Ошибка базы данных" });
      }

      if (user) {
        return res
          .status(400)
          .json({ error: "Email уже используется другим пользователем" });
      }

      db.run(
        "UPDATE users SET name = ?, email = ? WHERE id = ?",
        [name, email, req.session.userId],
        (err) => {
          if (err) {
            console.error("Ошибка базы данных:", err);
            return res
              .status(500)
              .json({ error: "Ошибка при обновлении профиля" });
          }

          req.session.userName = name;
          req.session.userEmail = email;

          res.json({ success: true, message: "Профиль обновлен" });
        }
      );
    }
  );
});

app.post("/upload", requireAuth, upload.single("filedata"), (req, res) => {
  const file = req.file;

  if (!file) {
    return res.send(`
            <html>
                <head><title>Ошибка</title></head>
                <body>
                    <h1>Ошибка!</h1>
                    <p>Файл не был выбран</p>
                    <a href="/">Назад</a>
                </body>
            </html>
        `);
  }

  db.run(
    "INSERT INTO files (user_id, name, path, size, type, upload_date) VALUES (?, ?, ?, ?, ?, ?)",
    [
      req.session.userId,
      file.originalname,
      file.path,
      file.size,
      file.mimetype,
      new Date().toISOString(),
    ],
    function (err) {
      if (err) {
        console.error("Ошибка базы данных:", err);
        return res.send("Ошибка при сохранении в базу данных");
      }

      res.redirect("/files");
    }
  );
});

app.get("/api/files", requireAuthAPI, (req, res) => {
  db.all(
    "SELECT * FROM files WHERE user_id = ? ORDER BY upload_date DESC",
    [req.session.userId],
    (err, rows) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ error: "Ошибка базы данных" });
      }

      const files = rows.map((file) => ({
        ...file,
        upload_date: new Date(file.upload_date).toLocaleString(),
        size_formatted: formatSize(file.size),
      }));

      res.json(files);
    }
  );
});

app.get("/api/avatar", requireAuthAPI, (req, res) => {
  db.get(
    "SELECT * FROM avatars WHERE user_id = ? AND is_active = 1 ORDER BY upload_date DESC LIMIT 1",
    [req.session.userId],
    (err, avatar) => {
      if (err) {
        console.error("Ошибка базы данных при получении аватара:", err);
        return res
          .status(500)
          .json({ error: "Ошибка базы данных", exists: false });
      }

      if (!avatar) {
        return res.json({ exists: false });
      }

      const avatarData = {
        ...avatar,
        exists: true,
        upload_date: new Date(avatar.upload_date).toLocaleString(),
        size_formatted: formatSize(avatar.size),
        url: `/avatar/file/${avatar.id}`,
      };

      res.json(avatarData);
    }
  );
});

app.post(
  "/api/avatar",
  requireAuthAPI,
  avatarUpload.single("avatar"),
  (req, res) => {
    const file = req.file;

    if (!file) {
      return res.status(400).json({
        success: false,
        error: "Файл не был выбран или превышен допустимый размер",
      });
    }

    console.log("Загрузка аватара для пользователя:", req.session.userId);
    console.log("Файл:", file.originalname, "Размер:", file.size);

    db.run(
      "UPDATE avatars SET is_active = 0 WHERE user_id = ?",
      [req.session.userId],
      (err) => {
        if (err) {
          console.error("Ошибка обновления аватарок:", err);
        }

        db.run(
          "INSERT INTO avatars (user_id, filename, path, size, type, upload_date, is_active) VALUES (?, ?, ?, ?, ?, ?, ?)",
          [
            req.session.userId,
            file.originalname,
            file.path,
            file.size,
            file.mimetype,
            new Date().toISOString(),
            1,
          ],
          function (err) {
            if (err) {
              console.error("Ошибка базы данных при сохранении аватара:", err);
              return res.status(500).json({
                success: false,
                error: "Ошибка при сохранении аватарки: " + err.message,
              });
            }

            console.log("Аватар успешно сохранен, ID:", this.lastID);

            res.json({
              success: true,
              id: this.lastID,
              filename: file.originalname,
              size: file.size,
              type: file.mimetype,
              url: `/avatar/file/${this.lastID}`,
            });
          }
        );
      }
    );
  }
);

app.delete("/api/avatar", requireAuthAPI, (req, res) => {
  db.get(
    "SELECT * FROM avatars WHERE user_id = ? AND is_active = 1",
    [req.session.userId],
    (err, avatar) => {
      if (err) {
        console.error(err);
        return res
          .status(500)
          .json({ success: false, error: "Ошибка базы данных" });
      }

      if (!avatar) {
        return res
          .status(404)
          .json({ success: false, error: "Аватарка не найдена" });
      }

      fs.unlink(avatar.path, (err) => {
        if (err && err.code !== "ENOENT") {
          console.error("Ошибка удаления файла аватарки:", err);
        }

        db.run("DELETE FROM avatars WHERE id = ?", [avatar.id], (err) => {
          if (err) {
            console.error("Ошибка удаления аватара из БД:", err);
            return res
              .status(500)
              .json({ success: false, error: "Ошибка базы данных" });
          }

          res.json({ success: true });
        });
      });
    }
  );
});

app.get("/avatar/file/:id", (req, res) => {
  const id = req.params.id;

  db.get("SELECT * FROM avatars WHERE id = ?", [id], (err, avatar) => {
    if (err || !avatar) {
      return res.status(404).send("Аватарка не найдена");
    }

    if (!fs.existsSync(avatar.path)) {
      return res.status(404).send("Файл аватарки отсутствует");
    }

    res.type(avatar.type || "image/jpeg");
    res.sendFile(avatar.path);
  });
});

app.delete("/api/files/:id", requireAuthAPI, (req, res) => {
  const id = req.params.id;

  db.get(
    "SELECT * FROM files WHERE id = ? AND user_id = ?",
    [id, req.session.userId],
    (err, file) => {
      if (err) {
        console.error("Ошибка БД при поиске файла:", err);
        return res
          .status(500)
          .json({ success: false, error: "Ошибка базы данных" });
      }

      if (!file) {
        return res
          .status(404)
          .json({ success: false, error: "Файл не найден" });
      }

      fs.unlink(file.path, (err) => {
        if (err && err.code !== "ENOENT") {
          console.error("Ошибка удаления файла:", err);
        }

        db.run("DELETE FROM files WHERE id = ?", [id], (err) => {
          if (err) {
            console.error("Ошибка удаления файла из БД:", err);
            return res
              .status(500)
              .json({ success: false, error: "Ошибка базы данных" });
          }

          res.json({ success: true });
        });
      });
    }
  );
});

app.get("/download/:id", (req, res) => {
  const id = req.params.id;

  db.get("SELECT * FROM files WHERE id = ?", [id], (err, file) => {
    if (err || !file) {
      return res.status(404).send("Файл не найден");
    }

    if (!fs.existsSync(file.path)) {
      return res.status(404).send("Файл отсутствует на сервере");
    }

    res.download(file.path, file.name);
  });
});

app.listen(PORT, () => {
  console.log(`Сервер запущен: http://localhost:${PORT}`);
});

function formatSize(bytes) {
  if (bytes === 0) return "0 Б";
  const k = 1024;
  const sizes = ["Б", "КБ", "МБ", "ГБ"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    if (err.code === "LIMIT_FILE_SIZE") {
      return res
        .status(400)
        .json({ error: "Файл слишком большой. Максимальный размер: 5MB" });
    }
    console.error("Ошибка Multer:", err);
    return res
      .status(400)
      .json({ error: "Ошибка загрузки файла: " + err.message });
  } else if (err) {
    console.error("Общая ошибка:", err);
    return res.status(500).json({ error: "Внутренняя ошибка сервера" });
  }
  next();
});

app.use((req, res) => {
  res.status(404).send(`
        <html>
            <head><title>404 - Страница не найдена</title></head>
            <body>
                <h1>404 - Страница не найдена</h1>
                <p>Запрашиваемая страница не существует</p>
                <a href="/">На главную</a>
            </body>
        </html>
    `);
});
