const express = require('express');
const { Sequelize, DataTypes, Op } = require('sequelize');
const path = require('path');
const session = require('express-session');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
    secret: 'your-secret-key-change-in-production',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: 'database.sqlite',
    logging: false,
});
const Product = sequelize.define('Product', {
    name: { type: DataTypes.STRING, allowNull: false },
    price: { type: DataTypes.FLOAT, allowNull: false},
    description: { type: DataTypes.TEXT },
    image: { type: DataTypes.STRING },
});

const Category = sequelize.define('Category', {
    name: { type: DataTypes.STRING, allowNull: false},
});

const Supplier = sequelize.define('Supplier' , {
    name: { type: DataTypes.STRING, allowNull: false},
    contact: { type: DataTypes.STRING},
});

const User = sequelize.define('User', {
    username: { type: DataTypes.STRING, allowNull: false, unique: true },
    email: { type: DataTypes.STRING, allowNull: false, unique: true },
    password: { type: DataTypes.STRING, allowNull: false },
    firstName: { type: DataTypes.STRING },
    lastName: { type: DataTypes.STRING },
    phone: { type: DataTypes.STRING },
    address: { type: DataTypes.TEXT },
    role: { type: DataTypes.STRING, defaultValue: 'user', allowNull: false },
});
Product.belongsTo(Category);
Product.belongsTo(Supplier);
Category.hasMany(Product);
Supplier.hasMany(Product);

const requireAuth = (req, res, next) => {
    if (req.session.userId) {
        next();
    } else {
        res.redirect('/login');
    }
};

const requireAdmin = (req, res, next) => {
    if (req.session.userId && req.session.user && req.session.user.role === 'admin') {
        next();
    } else {
        res.status(403).send('Доступ запрещен. Требуются права администратора.');
    }
};

app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    res.locals.isAuthenticated = !!req.session.userId;
    res.locals.isAdmin = req.session.user && req.session.user.role === 'admin';
    next();
});

app.use((req, res, next) => {
    if (!req.session.cart) {
        req.session.cart = [];
    }
    next();
});

app.get('/', async (req, res) => {
    try {
        const featuredProducts = await Product.findAll({
            include: [Category, Supplier],
            limit: 6,
            order: [['id', 'DESC']]
        });
        res.render('home', { featuredProducts });
    } catch (error) {
        console.error('Error fetching featured products:', error);
        res.render('home', { featuredProducts: [] });
    }
});

app.get('/catalog', async (req, res) => {
    try {
        const products = await Product.findAll({
            include: [Category, Supplier],
        });
        const categories = await Category.findAll();
        res.render('catalog', { products, categories });
    } catch (error) {
        console.error('Error fetching products:', error);
        res.render('catalog', { products: [], categories: [] });
    }
});

app.get('/login', (req, res) => {
    if (req.session.userId) {
        if (req.session.user && req.session.user.role === 'admin') {
            return res.redirect('/admin');
        }
        return res.redirect('/profile');
    }
    res.render('login', { error: null });
});

app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ where: { email } });
        
        if (!user) {
            return res.render('login', { error: 'Неверный email или пароль' });
        }
        
        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
            return res.render('login', { error: 'Неверный email или пароль' });
        }
        
        req.session.userId = user.id;
        req.session.user = {
            id: user.id,
            username: user.username,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role
        };
        
        if (user.role === 'admin') {
            res.redirect('/admin');
        } else {
            res.redirect('/profile');
        }
    } catch (error) {
        console.error('Login error:', error);
        res.render('login', { error: 'Ошибка при входе в систему' });
    }
});

app.get('/register', (req, res) => {
    if (req.session.userId) {
        return res.redirect('/profile');
    }
    res.render('register', { error: null });
});

app.post('/register', async (req, res) => {
    try {
        const { username, email, password, firstName, lastName } = req.body;
        
        const existingUser = await User.findOne({
            where: {
                [Op.or]: [{ email }, { username }]
            }
        });
        
        if (existingUser) {
            return res.render('register', { error: 'Пользователь с таким email или именем уже существует' });
        }
        
        const hashedPassword = await bcrypt.hash(password, 10);
        
        const user = await User.create({
            username,
            email,
            password: hashedPassword,
            firstName: firstName || null,
            lastName: lastName || null,
            role: 'user'
        });
        
        req.session.userId = user.id;
        req.session.user = {
            id: user.id,
            username: user.username,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role
        };
        
        res.redirect('/profile');
    } catch (error) {
        console.error('Registration error:', error);
        res.render('register', { error: 'Ошибка при регистрации' });
    }
});

app.post('/logout', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
        }
        res.redirect('/');
    });
});

app.get('/profile', requireAuth, async (req, res) => {
    try {
        const user = await User.findByPk(req.session.userId);
        res.render('profile', { user });
    } catch (error) {
        console.error('Error fetching user:', error);
        res.redirect('/login');
    }
});

app.post('/profile', requireAuth, async (req, res) => {
    try {
        const { firstName, lastName, phone, address } = req.body;
        await User.update(
            { firstName, lastName, phone, address },
            { where: { id: req.session.userId } }
        );
        
        const user = await User.findByPk(req.session.userId);
        req.session.user = {
            id: user.id,
            username: user.username,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role
        };
        
        res.redirect('/profile');
    } catch (error) {
        console.error('Error updating profile:', error);
        res.redirect('/profile');
    }
});

app.get('/cart', requireAuth, (req, res) => {
    if (req.session.user && req.session.user.role === 'admin') {
        return res.redirect('/admin');
    }
    const cart = req.session.cart || [];
    let total = 0;
    cart.forEach(item => {
        total += item.price * item.quantity;
    });
    res.render('cart', { cart, total });
});

app.post('/cart/add/:id', requireAuth, async (req, res) => {
    if (req.session.user && req.session.user.role === 'admin') {
        return res.status(403).json({ error: 'Администраторы не могут добавлять товары в корзину' });
    }
    
    try {
        const productId = parseInt(req.params.id);
        const product = await Product.findByPk(productId);
        
        if (!product) {
            return res.status(404).json({ error: 'Товар не найден' });
        }
        
        const cart = req.session.cart || [];
        const existingItem = cart.find(item => item.id === productId);
        
        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                quantity: 1
            });
        }
        
        req.session.cart = cart;
        res.json({ success: true, cartCount: cart.length });
    } catch (error) {
        console.error('Error adding to cart:', error);
        res.status(500).json({ error: 'Ошибка при добавлении товара' });
    }
});

app.post('/cart/remove/:id', requireAuth, (req, res) => {
    if (req.session.user && req.session.user.role === 'admin') {
        return res.redirect('/admin');
    }
    const productId = parseInt(req.params.id);
    const cart = req.session.cart || [];
    req.session.cart = cart.filter(item => item.id !== productId);
    res.redirect('/cart');
});

app.post('/cart/update', requireAuth, (req, res) => {
    if (req.session.user && req.session.user.role === 'admin') {
        return res.redirect('/admin');
    }
    const { id, quantity } = req.body;
    const cart = req.session.cart || [];
    const item = cart.find(item => item.id === parseInt(id));
    if (item) {
        item.quantity = parseInt(quantity) || 1;
    }
    req.session.cart = cart;
    res.redirect('/cart');
});

app.get('/admin', requireAdmin, async (req, res) => {
    const products = await Product.findAll({
        include: [Category, Supplier],
    });
    res.render('index', { products });
});

app.get('/add-category', requireAdmin, (req, res) => {
    res.render('add-category');
});

app.get('/add-supplier', requireAdmin, (req, res) => {
    res.render('add-supplier');
});

app.get('/add-product', requireAdmin, async (req, res) => {
    try {
        const categories = await Category.findAll();
        const suppliers = await Supplier.findAll();
        res.render('add-product', { categories, suppliers});
    } catch (error) {
        console.error('Error fetching categories or suppliers', error);
        res.status(500).send('Internal Server Error');
    }
});

app.get('/edit-product/:id', requireAdmin, async (req, res) => {
    try {
        const productId = req.params.id;
        const product = await Product.findByPk(productId, {
            include: [Category, Supplier],
        });
        const categories = await Category.findAll();
        const suppliers = await Supplier.findAll();
        res.render('edit-product', { product, categories, suppliers });
    } catch (error) {
        console.error('Error fetching product for edit: ', error);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/add-category', requireAdmin, async (req, res) => {
    const {name} = req.body;
    if (name) {
        await Category.create({ name });
    }
    res.redirect('/admin');
});

app.post('/add-supplier', requireAdmin, async (req, res) => {
    const {name, contact} = req.body;
    if (name) {
        await Supplier.create({ name, contact });
    }
    res.redirect('/admin');
});

app.post('/add-product', requireAdmin, async (req, res) => {
    const { name, price, categoryId, supplierId} = req.body;
    if (name && price && categoryId && supplierId) {
        try {
            await Product.create({
                name,
                price,
                CategoryId: categoryId,
                SupplierId: supplierId,
            });
            res.redirect('/admin');
        } catch (error) {
            console.error('Error adding product: ', error);
            res.status(500).send('Internal Server Error');
        }
    } else {
        res.status(400).send('All fields are required');
    }
});

app.post('/delete-product/:id', requireAdmin, async (req, res) => {
    try {
        const productId = req.params.id;
        await Product.destroy({
            where: { id: productId},
        });
        res.redirect('/admin');
    } catch(error) {
        console.error('Error deleting product: ', error);
        res.status(500).send('Internal Server Error');
    }
});

app.post('/edit-product/:id', requireAdmin, async (req, res) => {
    try {
        const productId = req.params.id;
        const { name, price, categoryId, supplierId } = req.body;

        await Product.update(
            { name, price, CategoryId: categoryId, SupplierId: supplierId},
            { where: { id: productId } }
        );
        res.redirect('/admin');
    } catch (error) {
        console.error('Error updating product: ', error);
        res.status(500).send('Internal Server Error');
    }
});

app.use((req, res) => {
    res.status(404).render('404');
});

(async () => {
    try {
        await sequelize.sync({ force: true });

        const category1 = await Category.create({ name: 'Electronics' });
        const category2 = await Category.create({ name: 'Books' });
        const category3 = await Category.create({ name: 'Clothing' });

        const supplier1 = await Supplier.create({ name: 'TechCorp', contact: 'techcorp@example.com'});
        const supplier2 = await Supplier.create({ name: 'BookStore', contact: 'contact@bookstore.com'});
        const supplier3 = await Supplier.create({ name: 'FashionHub', contact: 'info@fashionhub.com'});

        await Product.create({ name: 'Laptop', price: 1200.99, description: 'Powerful laptop for work and gaming', CategoryId: category1.id, SupplierId: supplier1.id});
        await Product.create({ name: 'Smartphone', price: 799.49, description: 'Latest smartphone with advanced features', CategoryId: category1.id, SupplierId: supplier1.id});
        await Product.create({ name: 'Science Fiction Book', price: 19.99, description: 'Amazing sci-fi novel', CategoryId: category2.id, SupplierId: supplier2.id});
        await Product.create({ name: 'T-Shirt', price: 29.99, description: 'Comfortable cotton t-shirt', CategoryId: category3.id, SupplierId: supplier3.id});
        await Product.create({ name: 'Tablet', price: 499.99, description: 'Portable tablet device', CategoryId: category1.id, SupplierId: supplier1.id});
        await Product.create({ name: 'Mystery Novel', price: 15.99, description: 'Thrilling mystery story', CategoryId: category2.id, SupplierId: supplier2.id});

        const hashedAdminPassword = await bcrypt.hash('admin123', 10);
        await User.create({
            username: 'admin',
            email: 'admin@example.com',
            password: hashedAdminPassword,
            firstName: 'Admin',
            lastName: 'User',
            role: 'admin'
        });

        const hashedUserPassword = await bcrypt.hash('user123', 10);
        await User.create({
            username: 'user',
            email: 'user@example.com',
            password: hashedUserPassword,
            firstName: 'Test',
            lastName: 'User',
            role: 'user'
        });

        app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
    } catch (error) {
        console.error('Error initializing the application: ', error);
    }
})();
