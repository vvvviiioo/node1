const cardQuestions = document.querySelectorAll(".card_question");

cardQuestions.forEach((question) => {
  question.addEventListener("click", () => {
    question.classList.toggle("active");
  });
});

let currentIndex = 0;

function moveCarousel(direction) {
  const track = document.querySelector(".carousel-track");
  const slides = document.querySelectorAll(".carousel-slide");
  const totalSlides = slides.length;
  const visibleSlides = 3;

  currentIndex = (currentIndex + direction + totalSlides) % totalSlides;

  const offset = currentIndex * (100 / visibleSlides);
  track.style.transform = `translateX(-${offset}%)`;
}
moveCarousel(0);
