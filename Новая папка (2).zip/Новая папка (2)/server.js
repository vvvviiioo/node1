const express = require("express");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();
const PORT = process.env.PORT || 3000;
const crypto = require("crypto");
const session = require("express-session");

const app = express();
const port = 3000;

app.use(express.json());


app.use(
  session({
    secret: "your-secret-key",
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }, 
  })
);

const dbPath = path.resolve(__dirname, "data/flower_shop.db");
const db = new sqlite3.Database(dbPath);

const sanitizeString = (str) => {
  if (!str) return "";
  if (typeof str !== "string") return String(str);
  return str.replace(/'/g, "''").replace(/[;\\]/g, "").trim();
};

const sanitizePrice = (price) => {
  const safePrice = parseFloat(String(price).replace(/[^\d.]/g, ""));
  return isNaN(safePrice) || safePrice < 0 ? 0 : Math.min(safePrice, 1000000);
};

function initDatabase() {

  db.run(
    `
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      price REAL NOT NULL,
      image TEXT NOT NULL,
      description TEXT,
      category TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `,
    (err) => {
      if (err) {
        console.error("Error creating products table:", err);
      } else {
        db.get("SELECT COUNT(*) as count FROM products", (err, row) => {
          if (!err && row.count === 0) {
            insertTestProducts();
          }
        });
      }
    }
  );


  db.run(
    `
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      image TEXT
    )
  `,
    (err) => {
      if (err) {
        console.error("Ошибка при создании таблицы users:", err);
      } else {
        db.get("SELECT COUNT(*) as count FROM users", (err, row) => {
          if (!err && row.count === 0) {
            insertTestUsers();
          }
        });
      }
    }
  );


  db.run(
    `
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER NOT NULL,
      customer_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      address TEXT NOT NULL,
      payment_method TEXT NOT NULL,
      product_name TEXT NOT NULL,
      product_price REAL NOT NULL,
      order_date DATETIME DEFAULT CURRENT_TIMESTAMP,
      status TEXT DEFAULT 'new',
      user_id INTEGER,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )
  `,
    (err) => {
      if (err) {
        console.error("Ошибка при создании таблицы orders:", err);
      } else {
        db.run(
          "CREATE INDEX IF NOT EXISTS idx_orders_user_id ON orders(user_id)"
        );
        db.run(
          "CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status)"
        );
        db.run(
          "CREATE INDEX IF NOT EXISTS idx_orders_order_date ON orders(order_date)"
        );
      }
    }
  );
}

function insertTestProducts() {
  const products = [
    {
      name: 'Букет "Нежность"',
      price: 3500,
      image:
        "https://content2.flowwow-images.com/data/flowers/1000x1000/23/1712833482_56407023.jpg",
      description: "Нежная композиция из розовых пионов и белых роз",
      category: "Классические букеты",
    },
    {
      name: 'Букет "Яркое лето"',
      price: 4200,
      image:
        "https://content2.flowwow-images.com/data/flowers/524x524/73/1692466741_89946173.jpg",
      description:
        "Яркий летний букет из подсолнухов, ромашек и полевых цветов",
      category: "Сезонные букеты",
    },
  ];

  const stmt = db.prepare(
    "INSERT INTO products (name, price, image, description, category) VALUES (?, ?, ?, ?, ?)"
  );

  products.forEach((product) => {
    stmt.run(
      sanitizeString(product.name),
      sanitizePrice(product.price),
      product.image,
      sanitizeString(product.description),
      sanitizeString(product.category)
    );
  });

  stmt.finalize();
}


function insertTestUsers() {
  const testUsers = [
    {
      username: "test_user",
      email: "test@example.com",
      password: crypto.createHash("sha256").update("password123").digest("hex"),
      image: "https://via.placeholder.com/150",
    },
  ];

  const stmt = db.prepare(
    "INSERT INTO users (username, email, password, image) VALUES (?, ?, ?, ?)"
  );

  testUsers.forEach((user) => {
    stmt.run(
      sanitizeString(user.username),
      sanitizeString(user.email),
      user.password,
      user.image
    );
  });

  stmt.finalize();
}

app.get("/api/users", (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 100, 500);

  db.all("SELECT * FROM users LIMIT ?", [limit], (err, users) => {
    if (err) {
      return res.status(500).json({ error: "Database error" });
    }
    const formattedUsers = users.map((users) => ({
      id: users.id,
      username: users.username,
      password: users.password,
      image: users.image,
      email: users.email,
    }));

    res.json(formattedUsers);
  });
});
app.get("/api/products", (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 100, 500);

  db.all("SELECT * FROM products LIMIT ?", [limit], (err, products) => {
    if (err) {
      return res.status(500).json({ error: "Database error" });
    }

    const formattedProducts = products.map((product) => ({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      description: product.description,
      category: product.category,
    }));

    res.json(formattedProducts);
  });
});

app.get("/api/products/:id", (req, res) => {
  const id = parseInt(req.params.id);

  if (isNaN(id) || id <= 0) {
    return res.status(400).json({ error: "Invalid product ID" });
  }

  db.get("SELECT * FROM products WHERE id = ?", [id], (err, product) => {
    if (err) {
      return res.status(500).json({ error: "Database error" });
    }

    if (!product) {
      return res.status(404).json({ error: "Product not found" });
    }

    res.json({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      description: product.description,
      category: product.category,
    });
  });
});

app.get("/api/products/category/:category", (req, res) => {
  const category = sanitizeString(req.params.category);

  db.all(
    "SELECT * FROM products WHERE category = ?",
    [category],
    (err, products) => {
      if (err) {
        return res.status(500).json({ error: "Database error" });
      }

      const formattedProducts = products.map((product) => ({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        description: product.description,
        category: product.category,
      }));

      res.json(formattedProducts);
    }
  );
});

app.post("/api/auth/register", (req, res) => {
  const { username, email, password, image } = req.body;

  const hashedPassword = crypto
    .createHash("sha256")
    .update(password)
    .digest("hex");

  db.run(
    "INSERT INTO users (username, email, password, image) VALUES (?, ?, ?, ?)",
    [username, email, hashedPassword, image],
    function (err) {
      if (err) {
        return res.status(400).json({ error: "Ошибка при регистрации" });
      }
      res.status(201).json({
        user: {
          id: this.lastID,
          username,
          email,
          image,
        },
      });
    }
  );
});

app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: "Email и пароль обязательны" });
  }

  const hashedPassword = crypto
    .createHash("sha256")
    .update(password)
    .digest("hex");

  db.get(
    "SELECT * FROM users WHERE email = ? AND password = ?",
    [email, hashedPassword],
    (err, user) => {
      if (err) {
        return res.status(500).json({ error: "Ошибка базы данных" });
      }

      if (!user) {
        return res.status(401).json({ error: "Неверный email или пароль" });
      }

      req.session.userId = user.id;
      res.json({
        message: "Вход выполнен успешно",
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          image: user.image,
        },
      });
    }
  );
});

app.post("/api/auth/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: "Ошибка при выходе" });
    }
    res.clearCookie("connect.sid");
    res.json({ message: "Выход выполнен успешно" });
  });
});

app.get("/api/auth/check", (req, res) => {
  if (!req.session.userId) {
    return res.json({ authenticated: false });
  }

  db.get(
    "SELECT * FROM users WHERE id = ?",
    [req.session.userId],
    (err, user) => {
      if (err || !user) {
        return res.json({ authenticated: false });
      }

      res.json({
        authenticated: true,
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          image: user.image,
        },
      });
    }
  );
});


app.post("/api/orders", (req, res) => {
  const {
    productId,
    name,
    email,
    phone,
    address,
    paymentMethod,
    productName,
    productPrice,
  } = req.body;
  const userId = req.session.userId;

  db.run(
    `INSERT INTO orders (product_id, customer_name, email, phone, address, payment_method, product_name, product_price, user_id)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      productId,
      name,
      email,
      phone,
      address,
      paymentMethod,
      productName,
      productPrice,
      userId,
    ],
    function (err) {
      if (err) {
        console.error("Ошибка при создании заказа:", err);
        res.status(500).json({ error: "Ошибка при создании заказа" });
        return;
      }
      res.json({ id: this.lastID });
    }
  );
});


app.get("/api/orders", (req, res) => {
  const userId = req.session.userId;

  if (!userId) {
    return res.status(401).json({ error: "Необходима авторизация" });
  }

  const sql = `
    SELECT * FROM orders 
    WHERE user_id = ? 
    ORDER BY order_date DESC
  `;

  db.all(sql, [userId], (err, orders) => {
    if (err) {
      console.error("Ошибка при получении заказов:", err);
      return res.status(500).json({ error: "Ошибка при получении заказов" });
    }
    res.json(orders);
  });
});


initDatabase();

app.use(express.static(__dirname));
app.use("/styles", express.static(path.join(__dirname, "styles")));
app.use("/img", express.static(path.join(__dirname, "img")));
app.use("/script.js", express.static(path.join(__dirname, "script.js")));

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "home.html"));
});

app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});
