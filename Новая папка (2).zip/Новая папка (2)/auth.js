document.addEventListener("DOMContentLoaded", function () {
  const modal = document.getElementById("authModal");
  const authBtn = document.getElementById("authBtn");
  const closeBtn = document.querySelector(".close");
  const tabBtns = document.querySelectorAll(".tab-btn");
  const loginForm = document.getElementById("loginForm");
  const registerForm = document.getElementById("registerForm");

  function updateAuthUI(user) {
    const profileImgs = document.querySelectorAll(
      'nav img[src*="profile.png"]'
    );
    if (user && user.image) {
      profileImgs.forEach((img) => {
        img.src = user.image;
      });
    }
  }

  function clearLocalStorage() {
    localStorage.clear();
    const profileImgs = document.querySelectorAll(
      'nav img[src*="profile.png"]'
    );
    profileImgs.forEach((img) => {
      img.src = "img/profile.png";
    });
  }

  function showProfileModal(user) {
    const profileHtml = `
      <div class="modal-content">
        <span class="close">&times;</span>
        <div class="profile-info">
          <img src="${user.image}" alt="Profile" class="profile-image">
          <h3>${user.username}</h3>
          <p>${user.email}</p>
          <button id="logoutBtn" class="logout-btn">Выйти</button>
        </div>
      </div>
    `;
    modal.innerHTML = profileHtml;
    modal.style.display = "block";

    const newCloseBtn = modal.querySelector(".close");
    const logoutBtn = modal.querySelector("#logoutBtn");

    if (newCloseBtn) {
      newCloseBtn.addEventListener("click", function () {
        modal.style.display = "none";
      });
    }

    if (logoutBtn) {
      logoutBtn.addEventListener("click", async function () {
        try {
          const response = await fetch("/api/auth/logout", {
            method: "POST",
            credentials: "include",
          });

          if (response.ok) {
            clearLocalStorage();
            modal.style.display = "none";
            window.location.reload();
          } else {
            throw new Error("Ошибка при выходе");
          }
        } catch (error) {
          console.error("Ошибка при выходе:", error);
          alert("Произошла ошибка при попытке выхода");
        }
      });
    }
  }

  async function checkAuthStatus() {
    try {
      const response = await fetch("/api/auth/check", {
        credentials: "include",
      });

      if (response.ok) {
        const data = await response.json();
        if (data.authenticated && data.user) {
          updateAuthUI(data.user);
          localStorage.setItem("user", JSON.stringify(data.user));
        }
      }
    } catch (error) {
      console.error("Ошибка при проверке авторизации:", error);
    }
  }

  checkAuthStatus();

  const savedUser = localStorage.getItem("user");
  if (savedUser) {
    try {
      const user = JSON.parse(savedUser);
      updateAuthUI(user);
    } catch (error) {
      console.error("Ошибка при чтении данных пользователя:", error);
      localStorage.removeItem("user");
    }
  }

  authBtn.addEventListener("click", function (e) {
    e.preventDefault();
    const savedUser = localStorage.getItem("user");
    if (savedUser) {
      try {
        showProfileModal(JSON.parse(savedUser));
      } catch (error) {
        console.error("Ошибка при отображении профиля:", error);
        localStorage.removeItem("user");
        modal.style.display = "block";
      }
    } else {
      modal.style.display = "block";
    }
  });

  closeBtn.addEventListener("click", function () {
    modal.style.display = "none";
  });

  window.addEventListener("click", function (e) {
    if (e.target === modal) {
      modal.style.display = "none";
    }
  });

  tabBtns.forEach((btn) => {
    btn.addEventListener("click", function () {
      const tab = this.dataset.tab;
      tabBtns.forEach((b) => b.classList.remove("active"));
      this.classList.add("active");

      if (tab === "login") {
        loginForm.classList.add("active");
        registerForm.classList.remove("active");
      } else {
        loginForm.classList.remove("active");
        registerForm.classList.add("active");
      }
    });
  });

  loginForm.addEventListener("submit", async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const data = {
      email: formData.get("email"),
      password: formData.get("password"),
    };

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (response.ok) {
        alert("Успешный вход!");
        modal.style.display = "none";
        localStorage.setItem("user", JSON.stringify(result.user));
        updateAuthUI(result.user);
        window.location.reload();
      } else {
        alert(
          result.error ||
            "Ошибка входа. Проверьте правильность введенных данных."
        );
      }
    } catch (error) {
      console.error("Ошибка при входе:", error);
      alert(
        "Произошла ошибка при попытке входа. Пожалуйста, попробуйте позже."
      );
    }
  });

  registerForm.addEventListener("submit", async function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    const data = {
      username: formData.get("username"),
      email: formData.get("email"),
      password: formData.get("password"),
      image: formData.get("image"),
    };

    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(data),
      });

      const result = await response.json();

      if (response.ok) {
        alert("Регистрация успешна!");
        modal.style.display = "none";
        localStorage.setItem("user", JSON.stringify(result.user));
        updateAuthUI(result.user);
        window.location.reload();
      } else {
        alert(
          result.error ||
            "Ошибка регистрации. Возможно, такой email уже зарегистрирован."
        );
      }
    } catch (error) {
      console.error("Ошибка при регистрации:", error);
      alert(
        "Произошла ошибка при попытке регистрации. Пожалуйста, попробуйте позже."
      );
    }
  });
});
