# Social - Онлайн постинг

Мини-проект для постинга фото, текста и файлов.

## Установка

```bash
npm install
```

## Запуск

```bash
npm start
```

Сервер запустится на http://localhost:3001

## API Endpoints

### Авторизация
- `POST /api/register` - Регистрация
- `POST /api/login` - Вход
- `POST /api/logout` - Выход
- `GET /api/check-auth` - Проверка авторизации
- `GET /api/profile` - Профиль пользователя (требуется авторизация)

### Посты
- `GET /api/posts` - Получить все посты (query: limit, offset)
- `GET /api/posts/:id` - Получить пост по ID
- `POST /api/posts` - Создать пост (требуется авторизация, multipart/form-data: text, image, file)
- `DELETE /api/posts/:id` - Удалить пост (требуется авторизация, только свои посты)

### Посты пользователя
- `GET /api/users/:id/posts` - Получить посты пользователя

## Тестовый аккаунт
- Email: admin@social.local
- Пароль: admin123

