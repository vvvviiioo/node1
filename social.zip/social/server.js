const express = require("express");
const path = require("path");
const fs = require("fs");
const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcrypt");
const multer = require("multer");
const session = require("express-session");

const PORT = process.env.PORT || 3001;
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use(
  session({
    secret: "social-secret-key-2025",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, httpOnly: true, maxAge: 30 * 24 * 60 * 60 * 1000 },
  })
);

app.listen(PORT, () => {
  console.log(`Сервер запущен на http://localhost:${PORT}`);
});

const dbPath = path.resolve(__dirname, "data/social.db");
const db = new sqlite3.Database(dbPath);

const uploadsDir = path.join(__dirname, "uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Настройка multer для загрузки файлов
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, "post-" + uniqueSuffix + path.extname(file.originalname));
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10 МБ
  fileFilter: (req, file, cb) => {
    // Разрешаем изображения и документы
    const allowedTypes = /jpeg|jpg|png|gif|webp|pdf|doc|docx|txt/;
    const extname = allowedTypes.test(
      path.extname(file.originalname).toLowerCase()
    );
    const mimetype =
      allowedTypes.test(file.mimetype) ||
      file.mimetype.startsWith("image/") ||
      file.mimetype.startsWith("application/pdf") ||
      file.mimetype.startsWith("application/msword") ||
      file.mimetype.startsWith("application/vnd.openxmlformats-officedocument");
    if (mimetype && extname) return cb(null, true);
    cb(new Error("Неподдерживаемый тип файла"));
  },
});

// Helpers
const sanitizeString = (str) => {
  if (!str) return "";
  if (typeof str !== "string") return String(str);
  return str.replace(/'/g, "''").replace(/[;\\]/g, "").trim();
};

const requireAuth = (req, res, next) => {
  if (req.session && req.session.userId) return next();
  return res.status(401).json({ error: "Требуется авторизация" });
};

// Инициализация базы данных
function initDatabase() {
  db.serialize(() => {
    // Таблица пользователей
    db.run(
      `
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        avatar TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `,
      (err) => {
        if (err) console.error("Error creating users table:", err);
      }
    );

    // Таблица постов
    db.run(
      `
      CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        text TEXT,
        image TEXT,
        file TEXT,
        file_name TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `,
      (err) => {
        if (err) console.error("Error creating posts table:", err);
      }
    );

    // Создание тестового администратора
    seedAdmin();
  });
}

function seedAdmin() {
  const adminUsername = "admin";
  const adminEmail = "admin@social.local";
  db.get(
    "SELECT id FROM users WHERE email = ?",
    [adminEmail],
    async (err, row) => {
      if (err || row) return;
      try {
        const passwordHash = await bcrypt.hash("admin123", 10);
        const stmt = db.prepare(
          "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)"
        );
        stmt.run(adminUsername, adminEmail, passwordHash, () => {});
        stmt.finalize();
      } catch (error) {
        console.error("Error creating admin:", error);
      }
    }
  );
}

initDatabase();

// Статические файлы
app.use("/uploads", express.static(uploadsDir));

// Главная страница
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

// --- API: Auth ---
app.post("/api/register", async (req, res) => {
  const body = req.body || {};
  const username = sanitizeString(body.username);
  const email = sanitizeString(body.email);
  const password = body.password || "";

  if (!username || username.length < 3)
    return res
      .status(400)
      .json({ error: "Имя пользователя должно быть не короче 3 символов" });
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({ error: "Введите корректный e-mail" });
  if (password.length < 6)
    return res
      .status(400)
      .json({ error: "Пароль должен быть не короче 6 символов" });

  db.get(
    "SELECT id FROM users WHERE email = ? OR username = ?",
    [email, username],
    async (err, row) => {
      if (err) return res.status(500).json({ error: "Database error" });
      if (row)
        return res
          .status(400)
          .json({
            error: "Пользователь с таким email или именем уже существует",
          });

      try {
        const passwordHash = await bcrypt.hash(password, 10);
        const stmt = db.prepare(
          "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)"
        );
        stmt.run(username, email, passwordHash, function (err) {
          if (err) return res.status(500).json({ error: "Database error" });
          req.session.userId = this.lastID;
          return res.status(201).json({
            id: this.lastID,
            username,
            email,
          });
        });
        stmt.finalize();
      } catch (error) {
        return res
          .status(500)
          .json({ error: "Ошибка при создании пользователя" });
      }
    }
  );
});

app.post("/api/login", (req, res) => {
  const body = req.body || {};
  const email = sanitizeString(body.email);
  const password = body.password || "";

  if (!email || !password)
    return res.status(400).json({ error: "Введите email и пароль" });

  db.get("SELECT * FROM users WHERE email = ?", [email], async (err, user) => {
    if (err) return res.status(500).json({ error: "Database error" });
    if (!user)
      return res.status(401).json({ error: "Неверный email или пароль" });

    try {
      const match = await bcrypt.compare(password, user.password_hash);
      if (!match)
        return res.status(401).json({ error: "Неверный email или пароль" });

      req.session.userId = user.id;
      return res.json({
        id: user.id,
        username: user.username,
        email: user.email,
        avatar: user.avatar,
      });
    } catch (error) {
      return res.status(500).json({ error: "Ошибка при проверке пароля" });
    }
  });
});

app.post("/api/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ error: "Ошибка при выходе" });
    return res.json({ success: true });
  });
});

app.get("/api/check-auth", (req, res) => {
  if (req.session && req.session.userId) {
    db.get(
      "SELECT id, username, email, avatar FROM users WHERE id = ?",
      [req.session.userId],
      (err, user) => {
        if (err || !user) return res.json({ authenticated: false });
        return res.json({ authenticated: true, user });
      }
    );
  } else {
    return res.json({ authenticated: false });
  }
});

// --- API: Posts ---
app.get("/api/posts", (req, res) => {
  const limit = Math.min(parseInt(req.query.limit) || 50, 100);
  const offset = parseInt(req.query.offset) || 0;

  db.all(
    `SELECT p.*, u.username, u.avatar 
     FROM posts p 
     JOIN users u ON p.user_id = u.id 
     ORDER BY p.created_at DESC 
     LIMIT ? OFFSET ?`,
    [limit, offset],
    (err, posts) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json(posts);
    }
  );
});

app.get("/api/posts/:id", (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id) || id <= 0)
    return res.status(400).json({ error: "Invalid post ID" });

  db.get(
    `SELECT p.*, u.username, u.avatar 
     FROM posts p 
     JOIN users u ON p.user_id = u.id 
     WHERE p.id = ?`,
    [id],
    (err, post) => {
      if (err) return res.status(500).json({ error: "Database error" });
      if (!post) return res.status(404).json({ error: "Post not found" });
      res.json(post);
    }
  );
});

app.post(
  "/api/posts",
  requireAuth,
  upload.fields([
    { name: "image", maxCount: 1 },
    { name: "file", maxCount: 1 },
  ]),
  (req, res) => {
    const body = req.body || {};
    const text = sanitizeString(body.text);
    const userId = req.session.userId;

    let imagePath = null;
    let filePath = null;
    let fileName = null;

    if (req.files) {
      if (req.files.image && req.files.image[0]) {
        imagePath = "/uploads/" + req.files.image[0].filename;
      }
      if (req.files.file && req.files.file[0]) {
        filePath = "/uploads/" + req.files.file[0].filename;
        fileName = req.files.file[0].originalname;
      }
    }

    if (!text && !imagePath && !filePath) {
      return res
        .status(400)
        .json({ error: "Пост должен содержать текст, изображение или файл" });
    }

    const stmt = db.prepare(
      "INSERT INTO posts (user_id, text, image, file, file_name) VALUES (?, ?, ?, ?, ?)"
    );
    stmt.run(
      userId,
      text || null,
      imagePath,
      filePath,
      fileName,
      function (err) {
        if (err) return res.status(500).json({ error: "Database error" });

        // Возвращаем созданный пост с данными пользователя
        db.get(
          `SELECT p.*, u.username, u.avatar 
       FROM posts p 
       JOIN users u ON p.user_id = u.id 
       WHERE p.id = ?`,
          [this.lastID],
          (err, post) => {
            if (err) return res.status(500).json({ error: "Database error" });
            res.status(201).json(post);
          }
        );
      }
    );
    stmt.finalize();
  }
);

app.delete("/api/posts/:id", requireAuth, (req, res) => {
  const id = parseInt(req.params.id);
  if (isNaN(id) || id <= 0)
    return res.status(400).json({ error: "Invalid post ID" });

  // Проверяем, что пост принадлежит пользователю
  db.get(
    "SELECT * FROM posts WHERE id = ? AND user_id = ?",
    [id, req.session.userId],
    (err, post) => {
      if (err) return res.status(500).json({ error: "Database error" });
      if (!post)
        return res
          .status(404)
          .json({ error: "Post not found or access denied" });

      // Удаляем файлы
      if (post.image && fs.existsSync(path.join(__dirname, post.image))) {
        fs.unlinkSync(path.join(__dirname, post.image));
      }
      if (post.file && fs.existsSync(path.join(__dirname, post.file))) {
        fs.unlinkSync(path.join(__dirname, post.file));
      }

      db.run("DELETE FROM posts WHERE id = ?", [id], (err) => {
        if (err) return res.status(500).json({ error: "Database error" });
        res.json({ success: true });
      });
    }
  );
});

// --- API: User Posts ---
app.get("/api/users/:id/posts", (req, res) => {
  const userId = parseInt(req.params.id);
  if (isNaN(userId) || userId <= 0)
    return res.status(400).json({ error: "Invalid user ID" });

  db.all(
    `SELECT p.*, u.username, u.avatar 
     FROM posts p 
     JOIN users u ON p.user_id = u.id 
     WHERE p.user_id = ? 
     ORDER BY p.created_at DESC`,
    [userId],
    (err, posts) => {
      if (err) return res.status(500).json({ error: "Database error" });
      res.json(posts);
    }
  );
});

// --- API: Profile ---
app.get("/api/profile", requireAuth, (req, res) => {
  db.get(
    "SELECT id, username, email, avatar, created_at FROM users WHERE id = ?",
    [req.session.userId],
    (err, user) => {
      if (err) return res.status(500).json({ error: "Database error" });
      if (!user)
        return res.status(404).json({ error: "Пользователь не найден" });
      return res.json(user);
    }
  );
});

// Обработка ошибок
app.use((req, res) => {
  res.status(404).json({ error: "Route not found" });
});
