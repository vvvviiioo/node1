import React, { useState } from "react";
import { useForm } from "react-hook-form";

export default function App() {
  return (
    <div className="max-w-xl mx-auto py-10">
      <h1 className="text-3xl font-bold text-center mb-10">
        Формы в React (Tailwind)
      </h1>

      <Card title="Форма A — useState">
        <FormA />
      </Card>

      <Card title="Форма B — react-hook-form">
        <FormB />
      </Card>

      <Card title="Пример валидации (react-hook-form)">
        <FormValidated />
      </Card>

      <Card title="Задание 2 — Простая проверка (логин + пароль)">
        <FormTask2 />
      </Card>
    </div>
  );
}

function Card({ title, children }) {
  return (
    <div className="bg-white shadow-md rounded-xl p-6 mb-8 border border-gray-200">
      <h2 className="text-xl font-semibold mb-4">{title}</h2>
      {children}
    </div>
  );
}

function FormA() {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");

  const submit = (e) => {
    e.preventDefault();
    console.log("Form A:", { login, password });
  };

  return (
    <form onSubmit={submit} className="flex flex-col gap-4">
      <input
        className="border rounded-lg p-2 outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Логин"
        value={login}
        onChange={(e) => setLogin(e.target.value)}
      />

      <input
        type="password"
        className="border rounded-lg p-2 outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Пароль"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />

      <button className="bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition">
        Отправить
      </button>
    </form>
  );
}

function FormB() {
  const { register, handleSubmit } = useForm();

  return (
    <form
      onSubmit={handleSubmit((data) => console.log("Form B:", data))}
      className="flex flex-col gap-4"
    >
      <input
        {...register("login")}
        className="border rounded-lg p-2 outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Логин"
      />

      <input
        {...register("password")}
        type="password"
        className="border rounded-lg p-2 outline-none focus:ring-2 focus:ring-blue-500"
        placeholder="Пароль"
      />

      <button className="bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition">
        Отправить
      </button>
    </form>
  );
}

function FormValidated() {
  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({ mode: "onChange" });

  return (
    <form
      onSubmit={handleSubmit((data) => console.log("Validated:", data))}
      className="flex flex-col gap-4"
    >
      <div>
        <input
          className={`border rounded-lg p-2 w-full outline-none ${
            errors.login
              ? "border-red-500"
              : "focus:ring-2 focus:ring-blue-500"
          }`}
          placeholder="Логин"
          {...register("login", { required: "Введите логин" })}
        />
        {errors.login && (
          <p className="text-red-500 text-sm mt-1">{errors.login.message}</p>
        )}
      </div>

      <div>
        <input
          type="password"
          className={`border rounded-lg p-2 w-full outline-none ${
            errors.password
              ? "border-red-500"
              : "focus:ring-2 focus:ring-blue-500"
          }`}
          placeholder="Пароль"
          {...register("password", {
            required: "Введите пароль",
            minLength: { value: 4, message: "Минимум 4 символа" },
          })}
        />
        {errors.password && (
          <p className="text-red-500 text-sm mt-1">{errors.password.message}</p>
        )}
      </div>

      <button
        disabled={!isValid}
        className={`py-2 rounded-lg text-white transition ${
          isValid
            ? "bg-blue-600 hover:bg-blue-700"
            : "bg-gray-400 cursor-not-allowed"
        }`}
      >
        Отправить
      </button>
    </form>
  );
}

function FormTask2() {
  const {
    register,
    handleSubmit,
    formState: { errors, isValid },
  } = useForm({
    mode: "onChange",
  });

  const onSubmit = (data) => console.log("Task 2:", data);

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4">

      {}
      <div>
        <input
          className={`border rounded-lg p-2 w-full outline-none ${
            errors.login
              ? "border-red-500"
              : "focus:ring-2 focus:ring-blue-500"
          }`}
          placeholder="Логин"
          {...register("login", {
            required: "Логин не может быть пустым",
          })}
        />
        {errors.login && (
          <p className="text-red-500 text-sm mt-1">{errors.login.message}</p>
        )}
      </div>

      {}
      <div>
        <input
          type="password"
          className={`border rounded-lg p-2 w-full outline-none ${
            errors.password
              ? "border-red-500"
              : "focus:ring-2 focus:ring-blue-500"
          }`}
          placeholder="Пароль"
          {...register("password", {
            required: "Введите пароль",
            minLength: {
              value: 4,
              message: "Пароль должен быть минимум 4 символа",
            },
          })}
        />
        {errors.password && (
          <p className="text-red-500 text-sm mt-1">
            {errors.password.message}
          </p>
        )}
      </div>

      {}
      <button
        disabled={!isValid}
        className={`py-2 rounded-lg text-white transition ${
          isValid
            ? "bg-blue-600 hover:bg-blue-700"
            : "bg-gray-400 cursor-not-allowed"
        }`}
      >
        Отправить
      </button>
    </form>
  );
}
