import React from "react";
import { useForm } from "react-hook-form";

export function FormB() {
  const { register, handleSubmit } = useForm();
  const onSubmit = (data) => console.log("Form B data:", data);

  return (
    <div>
      <h3>Форма B — useForm</h3>

      <form onSubmit={handleSubmit(onSubmit)}>
        <input {...register("login")} placeholder="Логин" />
        <br />

        <input {...register("password")} type="password" placeholder="Пароль" />
        <br />

        <button type="submit">Отправить</button>
      </form>
    </div>
  );
}
