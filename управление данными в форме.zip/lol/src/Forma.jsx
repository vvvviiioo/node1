import React, { useState } from "react";

export function FormA() {
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form A data:", { login, password });
  };

  return (
    <div style={{ marginBottom: "30px" }}>
      <h3>Форма A — useState</h3>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Логин"
          value={login}
          onChange={(e) => setLogin(e.target.value)}
        />
        <br />

        <input
          type="password"
          placeholder="Пароль"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <br />

        <button type="submit">Отправить</button>
      </form>
    </div>
  );
}
