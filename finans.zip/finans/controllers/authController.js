const User = require("../models/User");

const sanitizeString = (str) => {
  if (!str) return "";
  if (typeof str !== "string") return String(str);
  return str.replace(/'/g, "''").replace(/[;\\]/g, "").trim();
};

class AuthController {
  static async register(req, res) {
    try {
      const body = req.body || {};
      const username = sanitizeString(body.username);
      const email = sanitizeString(body.email);
      const password = body.password || "";

      if (!username || username.length < 3)
        return res
          .status(400)
          .json({ error: "Имя пользователя должно быть не короче 3 символов" });
      if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
        return res.status(400).json({ error: "Введите корректный e-mail" });
      if (password.length < 6)
        return res
          .status(400)
          .json({ error: "Пароль должен быть не короче 6 символов" });

      const existingUser = await User.findByEmailOrUsername(email, username);
      if (existingUser)
        return res
          .status(400)
          .json({
            error: "Пользователь с таким email или именем уже существует",
          });

      const userId = await User.create(username, email, password);
      req.session.userId = userId;

      return res.status(201).json({
        id: userId,
        username,
        email,
      });
    } catch (error) {
      console.error("Register error:", error);
      return res.status(500).json({ error: "Ошибка при создании пользователя" });
    }
  }

  static async login(req, res) {
    try {
      const body = req.body || {};
      const email = sanitizeString(body.email);
      const password = body.password || "";

      if (!email || !password)
        return res.status(400).json({ error: "Введите email и пароль" });

      const user = await User.findByEmail(email);
      if (!user)
        return res.status(401).json({ error: "Неверный email или пароль" });

      const match = await User.verifyPassword(password, user.password_hash);
      if (!match)
        return res.status(401).json({ error: "Неверный email или пароль" });

      req.session.userId = user.id;
      return res.json({
        id: user.id,
        username: user.username,
        email: user.email,
      });
    } catch (error) {
      console.error("Login error:", error);
      return res.status(500).json({ error: "Ошибка при проверке пароля" });
    }
  }

  static async logout(req, res) {
    req.session.destroy((err) => {
      if (err) return res.status(500).json({ error: "Ошибка при выходе" });
      return res.json({ success: true });
    });
  }

  static async checkAuth(req, res) {
    try {
      if (req.session && req.session.userId) {
        const user = await User.findById(req.session.userId);
        if (!user) return res.json({ authenticated: false });
        return res.json({
          authenticated: true,
          user: {
            id: user.id,
            username: user.username,
            email: user.email,
          },
        });
      } else {
        return res.json({ authenticated: false });
      }
    } catch (error) {
      console.error("Check auth error:", error);
      return res.json({ authenticated: false });
    }
  }
}

module.exports = AuthController;

