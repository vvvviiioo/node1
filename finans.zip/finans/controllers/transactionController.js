const Transaction = require("../models/Transaction");
const Account = require("../models/Account");
const User = require("../models/User");

class TransactionController {
  static async getTransactions(req, res) {
    try {
      const userId = req.session.userId;
      const accountId = req.query.account_id
        ? parseInt(req.query.account_id)
        : null;
      const limit = Math.min(parseInt(req.query.limit) || 50, 100);
      const offset = parseInt(req.query.offset) || 0;

      let transactions;
      if (accountId) {
        const account = await Account.findById(accountId);
        if (!account)
          return res.status(404).json({ error: "Счёт не найден" });
        if (account.user_id !== userId)
          return res.status(403).json({ error: "Доступ запрещён" });
        transactions = await Transaction.findByAccountId(accountId, limit, offset);
      } else {
        transactions = await Transaction.findByUserId(userId, limit, offset);
      }

      return res.json(transactions);
    } catch (error) {
      console.error("Get transactions error:", error);
      return res.status(500).json({ error: "Ошибка при получении транзакций" });
    }
  }

  static async deposit(req, res) {
    try {
      const userId = req.session.userId;
      const { account_id, amount, description } = req.body;

      if (!account_id || !amount)
        return res.status(400).json({ error: "Укажите счёт и сумму" });

      const accountId = parseInt(account_id);
      const depositAmount = parseFloat(amount);

      if (isNaN(accountId) || accountId <= 0)
        return res.status(400).json({ error: "Неверный ID счёта" });
      if (isNaN(depositAmount) || depositAmount <= 0)
        return res.status(400).json({ error: "Сумма должна быть больше нуля" });

      const account = await Account.findById(accountId);
      if (!account)
        return res.status(404).json({ error: "Счёт не найден" });
      if (account.user_id !== userId)
        return res.status(403).json({ error: "Доступ запрещён" });

      const transactionId = await Transaction.create({
        user_id: userId,
        account_id: accountId,
        type: "deposit",
        amount: depositAmount,
        description: description || "Пополнение счёта",
      });

      const transaction = await Transaction.findById(transactionId);
      return res.status(201).json(transaction);
    } catch (error) {
      console.error("Deposit error:", error);
      return res.status(500).json({ error: "Ошибка при пополнении счёта" });
    }
  }

  static async payment(req, res) {
    try {
      const userId = req.session.userId;
      const { account_id, amount, description } = req.body;

      if (!account_id || !amount)
        return res.status(400).json({ error: "Укажите счёт и сумму" });

      const accountId = parseInt(account_id);
      const paymentAmount = parseFloat(amount);

      if (isNaN(accountId) || accountId <= 0)
        return res.status(400).json({ error: "Неверный ID счёта" });
      if (isNaN(paymentAmount) || paymentAmount <= 0)
        return res.status(400).json({ error: "Сумма должна быть больше нуля" });

      const account = await Account.findById(accountId);
      if (!account)
        return res.status(404).json({ error: "Счёт не найден" });
      if (account.user_id !== userId)
        return res.status(403).json({ error: "Доступ запрещён" });
      if (account.balance < paymentAmount)
        return res.status(400).json({ error: "Недостаточно средств на счёте" });

      if (!description || description.trim().length === 0)
        return res.status(400).json({ error: "Укажите описание покупки" });

      const transactionId = await Transaction.create({
        user_id: userId,
        account_id: accountId,
        type: "payment",
        amount: paymentAmount,
        description: description.trim(),
      });

      const transaction = await Transaction.findById(transactionId);
      return res.status(201).json(transaction);
    } catch (error) {
      console.error("Payment error:", error);
      return res.status(500).json({ error: "Ошибка при оплате" });
    }
  }

  static async transfer(req, res) {
    try {
      const userId = req.session.userId;
      const { account_id, recipient_email, recipient_account_id, amount, description } = req.body;

      if (!account_id || !recipient_email || !recipient_account_id || !amount)
        return res.status(400).json({ error: "Заполните все обязательные поля" });

      const accountId = parseInt(account_id);
      const recipientAccountId = parseInt(recipient_account_id);
      const transferAmount = parseFloat(amount);

      if (isNaN(accountId) || accountId <= 0)
        return res.status(400).json({ error: "Неверный ID счёта отправителя" });
      if (isNaN(recipientAccountId) || recipientAccountId <= 0)
        return res.status(400).json({ error: "Неверный ID счёта получателя" });
      if (isNaN(transferAmount) || transferAmount <= 0)
        return res.status(400).json({ error: "Сумма должна быть больше нуля" });
      if (accountId === recipientAccountId)
        return res.status(400).json({ error: "Нельзя перевести деньги на тот же счёт" });

      const account = await Account.findById(accountId);
      if (!account)
        return res.status(404).json({ error: "Счёт отправителя не найден" });
      if (account.user_id !== userId)
        return res.status(403).json({ error: "Доступ запрещён" });
      if (account.balance < transferAmount)
        return res.status(400).json({ error: "Недостаточно средств на счёте" });

      const recipientUser = await User.findByEmail(recipient_email);
      if (!recipientUser)
        return res.status(404).json({ error: "Получатель не найден" });

      const recipientAccount = await Account.findById(recipientAccountId);
      if (!recipientAccount)
        return res.status(404).json({ error: "Счёт получателя не найден" });
      if (recipientAccount.user_id !== recipientUser.id)
        return res.status(400).json({ error: "Счёт не принадлежит указанному получателю" });

      const transactionId = await Transaction.create({
        user_id: userId,
        account_id: accountId,
        type: "transfer_out",
        amount: transferAmount,
        description: description || `Перевод пользователю ${recipientUser.username}`,
        recipient_user_id: recipientUser.id,
        recipient_account_id: recipientAccountId,
      });

      const transaction = await Transaction.findById(transactionId);
      return res.status(201).json(transaction);
    } catch (error) {
      console.error("Transfer error:", error);
      return res.status(500).json({ error: "Ошибка при переводе" });
    }
  }

  static async getTransaction(req, res) {
    try {
      const userId = req.session.userId;
      const transactionId = parseInt(req.params.id);

      if (isNaN(transactionId) || transactionId <= 0)
        return res.status(400).json({ error: "Неверный ID транзакции" });

      const transaction = await Transaction.findById(transactionId);
      if (!transaction)
        return res.status(404).json({ error: "Транзакция не найдена" });
      const account = await Account.findById(transaction.account_id);
      if (account.user_id !== userId)
        return res.status(403).json({ error: "Доступ запрещён" });

      return res.json(transaction);
    } catch (error) {
      console.error("Get transaction error:", error);
      return res.status(500).json({ error: "Ошибка при получении транзакции" });
    }
  }
}

module.exports = TransactionController;

