const Account = require("../models/Account");

class AccountController {
  static async getAccounts(req, res) {
    try {
      const userId = req.session.userId;
      const accounts = await Account.findByUserId(userId);
      return res.json(accounts);
    } catch (error) {
      console.error("Get accounts error:", error);
      return res.status(500).json({ error: "Ошибка при получении счетов" });
    }
  }

  static async createAccount(req, res) {
    try {
      const userId = req.session.userId;
      const { name, currency = "RUB" } = req.body;

      if (!name || name.trim().length === 0)
        return res.status(400).json({ error: "Укажите название счёта" });

      const accountId = await Account.create(userId, name.trim(), currency);
      const account = await Account.findById(accountId);

      return res.status(201).json(account);
    } catch (error) {
      console.error("Create account error:", error);
      return res.status(500).json({ error: "Ошибка при создании счёта" });
    }
  }

  static async getAccount(req, res) {
    try {
      const userId = req.session.userId;
      const accountId = parseInt(req.params.id);

      if (isNaN(accountId) || accountId <= 0)
        return res.status(400).json({ error: "Неверный ID счёта" });

      const account = await Account.findById(accountId);
      if (!account)
        return res.status(404).json({ error: "Счёт не найден" });

      if (account.user_id !== userId)
        return res.status(403).json({ error: "Доступ запрещён" });

      return res.json(account);
    } catch (error) {
      console.error("Get account error:", error);
      return res.status(500).json({ error: "Ошибка при получении счёта" });
    }
  }

  static async deleteAccount(req, res) {
    try {
      const userId = req.session.userId;
      const accountId = parseInt(req.params.id);

      if (isNaN(accountId) || accountId <= 0)
        return res.status(400).json({ error: "Неверный ID счёта" });

      const account = await Account.findById(accountId);
      if (!account)
        return res.status(404).json({ error: "Счёт не найден" });

      if (account.user_id !== userId)
        return res.status(403).json({ error: "Доступ запрещён" });

      const deleted = await Account.delete(accountId, userId);
      if (deleted === 0)
        return res.status(404).json({ error: "Счёт не найден" });

      return res.json({ success: true });
    } catch (error) {
      console.error("Delete account error:", error);
      return res.status(500).json({ error: "Ошибка при удалении счёта" });
    }
  }
}

module.exports = AccountController;

