const express = require("express");
const router = express.Router();
const TransactionController = require("../controllers/transactionController");
const requireAuth = require("../middleware/requireAuth");

router.get("/", requireAuth, TransactionController.getTransactions);
router.get("/:id", requireAuth, TransactionController.getTransaction);
router.post("/deposit", requireAuth, TransactionController.deposit);
router.post("/payment", requireAuth, TransactionController.payment);
router.post("/transfer", requireAuth, TransactionController.transfer);

module.exports = router;

