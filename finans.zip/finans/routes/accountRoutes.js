const express = require("express");
const router = express.Router();
const AccountController = require("../controllers/accountController");
const requireAuth = require("../middleware/requireAuth");

router.get("/", requireAuth, AccountController.getAccounts);
router.post("/", requireAuth, AccountController.createAccount);
router.get("/:id", requireAuth, AccountController.getAccount);
router.delete("/:id", requireAuth, AccountController.deleteAccount);

module.exports = router;

