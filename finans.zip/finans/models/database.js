const sqlite3 = require("sqlite3").verbose();
const path = require("path");
const fs = require("fs");
const bcrypt = require("bcrypt");

const dbPath = path.resolve(__dirname, "../data/finans.db");
const db = new sqlite3.Database(dbPath);

const dataDir = path.join(__dirname, "../data");
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

function initDatabase() {
  db.serialize(() => {
    db.run(
      `
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password_hash TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `,
      (err) => {
        if (err) console.error("Error creating users table:", err);
      }
    );

    db.run(
      `
      CREATE TABLE IF NOT EXISTS accounts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        balance REAL DEFAULT 0,
        currency TEXT DEFAULT 'RUB',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      )
    `,
      (err) => {
        if (err) console.error("Error creating accounts table:", err);
      }
    );

    db.run(
      `
      CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        account_id INTEGER NOT NULL,
        type TEXT NOT NULL CHECK(type IN ('deposit', 'payment', 'transfer_out', 'transfer_in')),
        amount REAL NOT NULL,
        description TEXT,
        recipient_user_id INTEGER,
        recipient_account_id INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE,
        FOREIGN KEY (recipient_user_id) REFERENCES users(id) ON DELETE SET NULL,
        FOREIGN KEY (recipient_account_id) REFERENCES accounts(id) ON DELETE SET NULL
      )
    `,
      (err) => {
        if (err) console.error("Error creating transactions table:", err);
      }
    );

    seedAdmin();
  });
}

function seedAdmin() {
  const adminUsername = "admin";
  const adminEmail = "admin@finans.local";
  db.get(
    "SELECT id FROM users WHERE email = ?",
    [adminEmail],
    async (err, row) => {
      if (err || row) return;
      try {
        const passwordHash = await bcrypt.hash("admin123", 10);
        const stmt = db.prepare(
          "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)"
        );
        stmt.run(adminUsername, adminEmail, passwordHash, async function() {
          const userId = this.lastID;
          const accountStmt = db.prepare(
            "INSERT INTO accounts (user_id, name, balance) VALUES (?, ?, ?)"
          );
          accountStmt.run(userId, "Основной счёт", 10000, () => {});
          accountStmt.finalize();
        });
        stmt.finalize();
      } catch (error) {
        console.error("Error creating admin:", error);
      }
    }
  );
}

initDatabase();

module.exports = db;

