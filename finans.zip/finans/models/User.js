const db = require("./database");
const bcrypt = require("bcrypt");

class User {
  static async create(username, email, password) {
    return new Promise((resolve, reject) => {
      const passwordHash = bcrypt.hashSync(password, 10);
      const stmt = db.prepare(
        "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)"
      );
      stmt.run(username, email, passwordHash, function (err) {
        if (err) return reject(err);
        resolve(this.lastID);
      });
      stmt.finalize();
    });
  }

  static async findByEmail(email) {
    return new Promise((resolve, reject) => {
      db.get("SELECT * FROM users WHERE email = ?", [email], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });
  }

  static async findById(id) {
    return new Promise((resolve, reject) => {
      db.get("SELECT * FROM users WHERE id = ?", [id], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });
  }

  static async findByEmailOrUsername(email, username) {
    return new Promise((resolve, reject) => {
      db.get(
        "SELECT * FROM users WHERE email = ? OR username = ?",
        [email, username],
        (err, row) => {
          if (err) return reject(err);
          resolve(row);
        }
      );
    });
  }

  static async verifyPassword(password, hash) {
    return bcrypt.compare(password, hash);
  }
}

module.exports = User;

