const db = require("./database");
const Account = require("./Account");

class Transaction {
  static async create(data) {
    return new Promise(async (resolve, reject) => {
      const {
        user_id,
        account_id,
        type,
        amount,
        description,
        recipient_user_id = null,
        recipient_account_id = null,
      } = data;

      db.serialize(() => {
        db.run("BEGIN TRANSACTION");

        const stmt = db.prepare(
          `INSERT INTO transactions 
          (user_id, account_id, type, amount, description, recipient_user_id, recipient_account_id) 
          VALUES (?, ?, ?, ?, ?, ?, ?)`
        );

        stmt.run(
          user_id,
          account_id,
          type,
          amount,
          description,
          recipient_user_id,
          recipient_account_id,
          async function (err) {
            if (err) {
              db.run("ROLLBACK");
              return reject(err);
            }

            const transactionId = this.lastID;

            try {
              if (type === "deposit") {
                await Account.updateBalance(account_id, amount);
              } else if (type === "payment") {
                await Account.updateBalance(account_id, -amount);
              } else if (type === "transfer_out") {
                await Account.updateBalance(account_id, -amount);
                if (recipient_account_id) {
                  await Account.updateBalance(recipient_account_id, amount);
                  const recipientStmt = db.prepare(
                    `INSERT INTO transactions 
                    (user_id, account_id, type, amount, description, recipient_user_id, recipient_account_id) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)`
                  );
                  recipientStmt.run(
                    recipient_user_id,
                    recipient_account_id,
                    "transfer_in",
                    amount,
                    description || `Перевод от пользователя #${user_id}`,
                    user_id,
                    account_id,
                    () => {}
                  );
                  recipientStmt.finalize();
                }
              }

              db.run("COMMIT", (err) => {
                if (err) {
                  db.run("ROLLBACK");
                  return reject(err);
                }
                resolve(transactionId);
              });
            } catch (error) {
              db.run("ROLLBACK");
              reject(error);
            }
          }
        );
        stmt.finalize();
      });
    });
  }

  static async findByUserId(userId, limit = 50, offset = 0) {
    return new Promise((resolve, reject) => {
      db.all(
        `SELECT t.*, a.name as account_name 
         FROM transactions t 
         JOIN accounts a ON t.account_id = a.id 
         WHERE t.user_id = ? 
         ORDER BY t.created_at DESC 
         LIMIT ? OFFSET ?`,
        [userId, limit, offset],
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        }
      );
    });
  }

  static async findByAccountId(accountId, limit = 50, offset = 0) {
    return new Promise((resolve, reject) => {
      db.all(
        `SELECT t.*, a.name as account_name 
         FROM transactions t 
         JOIN accounts a ON t.account_id = a.id 
         WHERE t.account_id = ? 
         ORDER BY t.created_at DESC 
         LIMIT ? OFFSET ?`,
        [accountId, limit, offset],
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        }
      );
    });
  }

  static async findById(id) {
    return new Promise((resolve, reject) => {
      db.get(
        `SELECT t.*, a.name as account_name 
         FROM transactions t 
         JOIN accounts a ON t.account_id = a.id 
         WHERE t.id = ?`,
        [id],
        (err, row) => {
          if (err) return reject(err);
          resolve(row);
        }
      );
    });
  }
}

module.exports = Transaction;

