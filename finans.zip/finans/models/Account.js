const db = require("./database");

class Account {
  static async create(userId, name, currency = "RUB") {
    return new Promise((resolve, reject) => {
      const stmt = db.prepare(
        "INSERT INTO accounts (user_id, name, balance, currency) VALUES (?, ?, ?, ?)"
      );
      stmt.run(userId, name, 0, currency, function (err) {
        if (err) return reject(err);
        resolve(this.lastID);
      });
      stmt.finalize();
    });
  }

  static async findByUserId(userId) {
    return new Promise((resolve, reject) => {
      db.all(
        "SELECT * FROM accounts WHERE user_id = ? ORDER BY created_at DESC",
        [userId],
        (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        }
      );
    });
  }

  static async findById(id) {
    return new Promise((resolve, reject) => {
      db.get("SELECT * FROM accounts WHERE id = ?", [id], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });
  }

  static async updateBalance(accountId, amount) {
    return new Promise((resolve, reject) => {
      db.run(
        "UPDATE accounts SET balance = balance + ? WHERE id = ?",
        [amount, accountId],
        function (err) {
          if (err) return reject(err);
          resolve(this.changes);
        }
      );
    });
  }

  static async delete(id, userId) {
    return new Promise((resolve, reject) => {
      db.run(
        "DELETE FROM accounts WHERE id = ? AND user_id = ?",
        [id, userId],
        function (err) {
          if (err) return reject(err);
          resolve(this.changes);
        }
      );
    });
  }
}

module.exports = Account;

