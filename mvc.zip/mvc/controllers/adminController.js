const { Product, Category, Supplier } = require('../models');

const dashboard = async (req, res) => {
    const products = await Product.findAll({
        include: [Category, Supplier],
    });
    res.render('index', { products });
};

const renderAddCategory = (req, res) => {
    res.render('add-category');
};

const renderAddSupplier = (req, res) => {
    res.render('add-supplier');
};

const renderAddProduct = async (req, res) => {
    try {
        const categories = await Category.findAll();
        const suppliers = await Supplier.findAll();
        res.render('add-product', { categories, suppliers });
    } catch (error) {
        console.error('Error fetching categories or suppliers', error);
        res.status(500).send('Internal Server Error');
    }
};

const renderEditProduct = async (req, res) => {
    try {
        const productId = req.params.id;
        const product = await Product.findByPk(productId, {
            include: [Category, Supplier],
        });
        const categories = await Category.findAll();
        const suppliers = await Supplier.findAll();
        res.render('edit-product', { product, categories, suppliers });
    } catch (error) {
        console.error('Error fetching product for edit: ', error);
        res.status(500).send('Internal Server Error');
    }
};

const createCategory = async (req, res) => {
    const { name } = req.body;
    if (name) {
        await Category.create({ name });
    }
    res.redirect('/admin');
};

const createSupplier = async (req, res) => {
    const { name, contact } = req.body;
    if (name) {
        await Supplier.create({ name, contact });
    }
    res.redirect('/admin');
};

const createProduct = async (req, res) => {
    const { name, price, categoryId, supplierId } = req.body;
    if (name && price && categoryId && supplierId) {
        try {
            await Product.create({
                name,
                price,
                CategoryId: categoryId,
                SupplierId: supplierId,
            });
            return res.redirect('/admin');
        } catch (error) {
            console.error('Error adding product: ', error);
            return res.status(500).send('Internal Server Error');
        }
    }
    return res.status(400).send('All fields are required');
};

const deleteProduct = async (req, res) => {
    try {
        const productId = req.params.id;
        await Product.destroy({
            where: { id: productId },
        });
        res.redirect('/admin');
    } catch (error) {
        console.error('Error deleting product: ', error);
        res.status(500).send('Internal Server Error');
    }
};

const updateProduct = async (req, res) => {
    try {
        const productId = req.params.id;
        const { name, price, categoryId, supplierId } = req.body;

        await Product.update(
            { name, price, CategoryId: categoryId, SupplierId: supplierId },
            { where: { id: productId } },
        );
        res.redirect('/admin');
    } catch (error) {
        console.error('Error updating product: ', error);
        res.status(500).send('Internal Server Error');
    }
};

module.exports = {
    dashboard,
    renderAddCategory,
    renderAddSupplier,
    renderAddProduct,
    renderEditProduct,
    createCategory,
    createSupplier,
    createProduct,
    deleteProduct,
    updateProduct,
};

