const { Product } = require('../models');

const ensureNotAdmin = (req, res) => {
    if (req.session.user && req.session.user.role === 'admin') {
        res.redirect('/admin');
        return true;
    }
    return false;
};

const viewCart = (req, res) => {
    if (ensureNotAdmin(req, res)) {
        return;
    }
    const cart = req.session.cart || [];
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    res.render('cart', { cart, total });
};

const addToCart = async (req, res) => {
    if (req.session.user && req.session.user.role === 'admin') {
        return res.status(403).json({ error: 'Администраторы не могут добавлять товары в корзину' });
    }

    try {
        const productId = parseInt(req.params.id, 10);
        const product = await Product.findByPk(productId);

        if (!product) {
            return res.status(404).json({ error: 'Товар не найден' });
        }

        const cart = req.session.cart || [];
        const existingItem = cart.find((item) => item.id === productId);

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                quantity: 1,
            });
        }

        req.session.cart = cart;
        return res.json({ success: true, cartCount: cart.length });
    } catch (error) {
        console.error('Error adding to cart:', error);
        return res.status(500).json({ error: 'Ошибка при добавлении товара' });
    }
};

const removeFromCart = (req, res) => {
    if (ensureNotAdmin(req, res)) {
        return;
    }
    const productId = parseInt(req.params.id, 10);
    const cart = req.session.cart || [];
    req.session.cart = cart.filter((item) => item.id !== productId);
    res.redirect('/cart');
};

const updateCart = (req, res) => {
    if (ensureNotAdmin(req, res)) {
        return;
    }
    const { id, quantity } = req.body;
    const cart = req.session.cart || [];
    const item = cart.find((cartItem) => cartItem.id === parseInt(id, 10));
    if (item) {
        item.quantity = parseInt(quantity, 10) || 1;
    }
    req.session.cart = cart;
    res.redirect('/cart');
};

module.exports = {
    viewCart,
    addToCart,
    removeFromCart,
    updateCart,
};

