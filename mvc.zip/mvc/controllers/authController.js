const bcrypt = require('bcrypt');
const { Op } = require('sequelize');
const { User } = require('../models');

const renderLogin = (req, res) => {
    if (req.session.userId) {
        if (req.session.user && req.session.user.role === 'admin') {
            return res.redirect('/admin');
        }
        return res.redirect('/profile');
    }
    return res.render('login', { error: null });
};

const login = async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await User.findOne({ where: { email } });

        if (!user) {
            return res.render('login', { error: 'Неверный email или пароль' });
        }

        const isValidPassword = await bcrypt.compare(password, user.password);
        if (!isValidPassword) {
            return res.render('login', { error: 'Неверный email или пароль' });
        }

        req.session.userId = user.id;
        req.session.user = {
            id: user.id,
            username: user.username,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role,
        };

        if (user.role === 'admin') {
            return res.redirect('/admin');
        }
        return res.redirect('/profile');
    } catch (error) {
        console.error('Login error:', error);
        return res.render('login', { error: 'Ошибка при входе в систему' });
    }
};

const renderRegister = (req, res) => {
    if (req.session.userId) {
        return res.redirect('/profile');
    }
    return res.render('register', { error: null });
};

const register = async (req, res) => {
    try {
        const { username, email, password, firstName, lastName } = req.body;

        const existingUser = await User.findOne({
            where: {
                [Op.or]: [{ email }, { username }],
            },
        });

        if (existingUser) {
            return res.render('register', { error: 'Пользователь с таким email или именем уже существует' });
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const user = await User.create({
            username,
            email,
            password: hashedPassword,
            firstName: firstName || null,
            lastName: lastName || null,
            role: 'user',
        });

        req.session.userId = user.id;
        req.session.user = {
            id: user.id,
            username: user.username,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role,
        };

        return res.redirect('/profile');
    } catch (error) {
        console.error('Registration error:', error);
        return res.render('register', { error: 'Ошибка при регистрации' });
    }
};

const logout = (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
        }
        res.redirect('/');
    });
};

module.exports = {
    renderLogin,
    login,
    renderRegister,
    register,
    logout,
};

