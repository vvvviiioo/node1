const { User } = require('../models');

const renderProfile = async (req, res) => {
    try {
        const user = await User.findByPk(req.session.userId);
        return res.render('profile', { user });
    } catch (error) {
        console.error('Error fetching user:', error);
        return res.redirect('/login');
    }
};

const updateProfile = async (req, res) => {
    try {
        const { firstName, lastName, phone, address } = req.body;
        await User.update(
            { firstName, lastName, phone, address },
            { where: { id: req.session.userId } },
        );

        const user = await User.findByPk(req.session.userId);
        req.session.user = {
            id: user.id,
            username: user.username,
            email: user.email,
            firstName: user.firstName,
            lastName: user.lastName,
            role: user.role,
        };

        return res.redirect('/profile');
    } catch (error) {
        console.error('Error updating profile:', error);
        return res.redirect('/profile');
    }
};

module.exports = {
    renderProfile,
    updateProfile,
};

