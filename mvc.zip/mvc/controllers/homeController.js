const { Product, Category, Supplier } = require('../models');

const getHome = async (req, res) => {
    try {
        const featuredProducts = await Product.findAll({
            include: [Category, Supplier],
            limit: 6,
            order: [['id', 'DESC']],
        });
        res.render('home', { featuredProducts });
    } catch (error) {
        console.error('Error fetching featured products:', error);
        res.render('home', { featuredProducts: [] });
    }
};

const getCatalog = async (req, res) => {
    try {
        const products = await Product.findAll({
            include: [Category, Supplier],
        });
        const categories = await Category.findAll();
        res.render('catalog', { products, categories });
    } catch (error) {
        console.error('Error fetching products:', error);
        res.render('catalog', { products: [], categories: [] });
    }
};

module.exports = {
    getHome,
    getCatalog,
};

