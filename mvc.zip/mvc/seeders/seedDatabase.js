const bcrypt = require('bcrypt');
const {
    Category,
    Supplier,
    Product,
    User,
} = require('../models');

const seedDatabase = async () => {
    const category1 = await Category.create({ name: 'Electronics' });
    const category2 = await Category.create({ name: 'Books' });
    const category3 = await Category.create({ name: 'Clothing' });

    const supplier1 = await Supplier.create({ name: 'TechCorp', contact: 'techcorp@example.com' });
    const supplier2 = await Supplier.create({ name: 'BookStore', contact: 'contact@bookstore.com' });
    const supplier3 = await Supplier.create({ name: 'FashionHub', contact: 'info@fashionhub.com' });

    await Product.create({
        name: 'Laptop',
        price: 1200.99,
        description: 'Powerful laptop for work and gaming',
        CategoryId: category1.id,
        SupplierId: supplier1.id,
    });
    await Product.create({
        name: 'Smartphone',
        price: 799.49,
        description: 'Latest smartphone with advanced features',
        CategoryId: category1.id,
        SupplierId: supplier1.id,
    });
    await Product.create({
        name: 'Science Fiction Book',
        price: 19.99,
        description: 'Amazing sci-fi novel',
        CategoryId: category2.id,
        SupplierId: supplier2.id,
    });
    await Product.create({
        name: 'T-Shirt',
        price: 29.99,
        description: 'Comfortable cotton t-shirt',
        CategoryId: category3.id,
        SupplierId: supplier3.id,
    });
    await Product.create({
        name: 'Tablet',
        price: 499.99,
        description: 'Portable tablet device',
        CategoryId: category1.id,
        SupplierId: supplier1.id,
    });
    await Product.create({
        name: 'Mystery Novel',
        price: 15.99,
        description: 'Thrilling mystery story',
        CategoryId: category2.id,
        SupplierId: supplier2.id,
    });

    const hashedAdminPassword = await bcrypt.hash('admin123', 10);
    await User.create({
        username: 'admin',
        email: 'admin@example.com',
        password: hashedAdminPassword,
        firstName: 'Admin',
        lastName: 'User',
        role: 'admin',
    });

    const hashedUserPassword = await bcrypt.hash('user123', 10);
    await User.create({
        username: 'user',
        email: 'user@example.com',
        password: hashedUserPassword,
        firstName: 'Test',
        lastName: 'User',
        role: 'user',
    });
};

module.exports = seedDatabase;

