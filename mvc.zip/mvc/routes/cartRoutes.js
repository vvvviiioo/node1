const express = require('express');
const {
    viewCart,
    addToCart,
    removeFromCart,
    updateCart,
} = require('../controllers/cartController');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

router.get('/', requireAuth, viewCart);
router.post('/add/:id', requireAuth, addToCart);
router.post('/remove/:id', requireAuth, removeFromCart);
router.post('/update', requireAuth, updateCart);

module.exports = router;

