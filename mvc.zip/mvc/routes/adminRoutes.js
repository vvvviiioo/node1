const express = require('express');
const {
    dashboard,
    renderAddCategory,
    renderAddSupplier,
    renderAddProduct,
    renderEditProduct,
    createCategory,
    createSupplier,
    createProduct,
    deleteProduct,
    updateProduct,
} = require('../controllers/adminController');
const { requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.use(requireAdmin);

router.get('/admin', dashboard);
router.get('/add-category', renderAddCategory);
router.get('/add-supplier', renderAddSupplier);
router.get('/add-product', renderAddProduct);
router.get('/edit-product/:id', renderEditProduct);

router.post('/add-category', createCategory);
router.post('/add-supplier', createSupplier);
router.post('/add-product', createProduct);
router.post('/delete-product/:id', deleteProduct);
router.post('/edit-product/:id', updateProduct);

module.exports = router;

