const express = require('express');
const { getHome, getCatalog } = require('../controllers/homeController');

const router = express.Router();

router.get('/', getHome);
router.get('/catalog', getCatalog);

module.exports = router;

