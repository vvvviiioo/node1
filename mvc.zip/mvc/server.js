const express = require('express');
const path = require('path');
const session = require('express-session');

const homeRoutes = require('./routes/homeRoutes');
const authRoutes = require('./routes/authRoutes');
const profileRoutes = require('./routes/profileRoutes');
const cartRoutes = require('./routes/cartRoutes');
const adminRoutes = require('./routes/adminRoutes');
const { notFound } = require('./controllers/errorController');
const { sequelize } = require('./models');
const setLocals = require('./middleware/locals');
const cartInitializer = require('./middleware/cart');
const seedDatabase = require('./seeders/seedDatabase');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
    secret: 'your-secret-key-change-in-production',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 },
}));

app.use(setLocals);
app.use(cartInitializer);

app.use('/', homeRoutes);
app.use('/', authRoutes);
app.use('/', profileRoutes);
app.use('/cart', cartRoutes);
app.use('/', adminRoutes);

app.use(notFound);

const start = async () => {
    try {
        await sequelize.sync({ force: true });
        await seedDatabase();
        app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
    } catch (error) {
        console.error('Error initializing the application: ', error);
    }
};

start();

module.exports = app;
