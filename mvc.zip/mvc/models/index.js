const sequelize = require('../config/database');
const Product = require('./Product');
const Category = require('./Category');
const Supplier = require('./Supplier');
const User = require('./User');

Category.hasMany(Product);
Supplier.hasMany(Product);
Product.belongsTo(Category);
Product.belongsTo(Supplier);

module.exports = {
    sequelize,
    Product,
    Category,
    Supplier,
    User,
};

