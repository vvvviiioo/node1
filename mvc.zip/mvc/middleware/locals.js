const setLocals = (req, res, next) => {
    res.locals.user = req.session.user || null;
    res.locals.isAuthenticated = !!req.session.userId;
    res.locals.isAdmin = req.session.user && req.session.user.role === 'admin';
    next();
};

module.exports = setLocals;

