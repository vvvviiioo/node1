const requireAuth = (req, res, next) => {
    if (req.session.userId) {
        return next();
    }
    return res.redirect('/login');
};

const requireAdmin = (req, res, next) => {
    if (req.session.userId && req.session.user && req.session.user.role === 'admin') {
        return next();
    }
    return res.status(403).send('Доступ запрещен. Требуются права администратора.');
};

module.exports = {
    requireAuth,
    requireAdmin,
};

